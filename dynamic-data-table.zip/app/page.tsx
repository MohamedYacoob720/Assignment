"use client";
import React, { useState } from "react";
import DataTable from "../src/components/DataTable";
import ManageColumnsModal from "../src/components/ManageColumnsModal";
import CsvImportButton from "../src/components/CsvImportButton";
import CsvExportButton from "../src/components/CsvExportButton";
import { Box, Container, Button, AppBar, Toolbar, Typography } from "@mui/material";
import ThemeToggle from "../src/components/ThemeToggle";

export default function Page() {
  const [openCols, setOpenCols] = useState(false);
  const [mode, setMode] = useState<"light" | "dark">("light");

  return (
    <Container maxWidth="xl" sx={{ mt: 2 }}>
      <AppBar position="static" color="transparent" elevation={0}>
        <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
          <Typography variant="h6">Dynamic Data Table Manager</Typography>
          <Box sx={{ display: "flex", gap: 1 }}>
            <CsvImportButton />
            <CsvExportButton />
            <Button variant="outlined" onClick={() => setOpenCols(true)}>Manage Columns</Button>
            <ThemeToggle mode={mode} toggle={() => setMode(m => (m === "light" ? "dark" : "light"))}/>
          </Box>
        </Toolbar>
      </AppBar>

      <Box sx={{ mt: 2 }}>
        <DataTable />
      </Box>

      <ManageColumnsModal open={openCols} onClose={() => setOpenCols(false)} />
    </Container>
  );
}
