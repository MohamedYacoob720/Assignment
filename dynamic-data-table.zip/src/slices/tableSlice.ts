import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { RowData, ColumnDef } from "../types";
import { v4 as uuidv4 } from "uuid";

type TableState = {
  rows: RowData[];
  columns: ColumnDef[];
  columnOrder: string[];
  editedRows: Record<string, Partial<RowData>>;
  importPreview?: { headers: string[]; sample: any[] } | null;
};

const defaultColumns: ColumnDef[] = [
  { key: "name", label: "Name", visible: true, editable: true },
  { key: "email", label: "Email", visible: true, editable: true },
  { key: "age", label: "Age", visible: true, editable: true },
  { key: "role", label: "Role", visible: true, editable: true },
];

const initialRows: RowData[] = [
  { id: uuidv4(), name: "Alice", email: "alice@example.com", age: 30, role: "Admin" },
  { id: uuidv4(), name: "Bob", email: "bob@example.com", age: 25, role: "User" },
];

const initialState: TableState = {
  rows: initialRows,
  columns: defaultColumns,
  columnOrder: defaultColumns.map(c => c.key),
  editedRows: {},
  importPreview: null,
};

const tableSlice = createSlice({
  name: "table",
  initialState,
  reducers: {
    setRows(state, action: PayloadAction<RowData[]>) { state.rows = action.payload; },
    addRow(state, action: PayloadAction<Partial<RowData>>) { state.rows.unshift({ id: uuidv4(), name: "", email: "", age: null, role: "", ...action.payload } as RowData); },
    updateRow(state, action: PayloadAction<{ id: string; changes: Partial<RowData> }>) {
      state.rows = state.rows.map(r => (r.id === action.payload.id ? { ...r, ...action.payload.changes } : r));
    },
    deleteRow(state, action: PayloadAction<string>) { state.rows = state.rows.filter(r => r.id !== action.payload); },
    setColumns(state, action: PayloadAction<ColumnDef[]>) { state.columns = action.payload; state.columnOrder = action.payload.map(c => c.key); },
    toggleColumnVisibility(state, action: PayloadAction<{ key: string; visible: boolean }>) {
      state.columns = state.columns.map(c => (c.key === action.payload.key ? { ...c, visible: action.payload.visible } : c));
    },
    addCustomColumn(state, action: PayloadAction<{ key: string; label: string }>) {
      const { key, label } = action.payload;
      if (!state.columns.find(c => c.key === key)) {
        state.columns.push({ key, label, visible: true, editable: true });
        state.columnOrder.push(key);
      }
    },
    setColumnOrder(state, action: PayloadAction<string[]>) { state.columnOrder = action.payload; },
    startEdit(state, action: PayloadAction<{ id: string; data: Partial<RowData> }>) { state.editedRows[action.payload.id] = action.payload.data; },
    setEditValue(state, action: PayloadAction<{ id: string; key: string; value: any }>) {
      state.editedRows[action.payload.id] = { ...(state.editedRows[action.payload.id] || {}), [action.payload.key]: action.payload.value };
    },
    saveAllEdits(state) {
      Object.keys(state.editedRows).forEach(id => { const changes = state.editedRows[id]; state.rows = state.rows.map(r => (r.id === id ? { ...r, ...changes } : r)); });
      state.editedRows = {};
    },
    cancelAllEdits(state) { state.editedRows = {}; },
    setImportPreview(state, action: PayloadAction<{ headers: string[]; sample: any[] } | null>) { state.importPreview = action.payload; }
  }
});

export const {
  setRows, addRow, updateRow, deleteRow, setColumns, toggleColumnVisibility, addCustomColumn, setColumnOrder,
  startEdit, setEditValue, saveAllEdits, cancelAllEdits, setImportPreview,
} = tableSlice.actions;

export default tableSlice.reducer;
