import React from "react";
import { Button } from "@mui/material";
import { useSelector } from "react-redux";
import { RootState } from "../store/store";
import { exportToCsv } from "../utils/csv";

export default function CsvExportButton() {
  const rows = useSelector((s: RootState) => s.table.rows);
  const columns = useSelector((s: RootState) => s.table.columns);

  return (
    <Button variant="outlined" onClick={() => exportToCsv(rows, columns)}>
      Export CSV
    </Button>
  );
}
