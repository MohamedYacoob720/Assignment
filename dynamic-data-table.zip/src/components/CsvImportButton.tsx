import React from "react";
import { Button } from "@mui/material";
import { parseCsvFile } from "../utils/csv";
import { useDispatch } from "react-redux";
import { setRows } from "../slices/tableSlice";
import { RowData } from "../types";
import { v4 as uuidv4 } from "uuid";

export default function CsvImportButton() {
  const dispatch = useDispatch();

  const handleFile = async (file?: File) => {
    if (!file) return;
    try {
      const { data, errors } = await parseCsvFile(file);
      if (errors.length) {
        alert("CSV parse errors: " + errors.map(e => e.message).join("; "));
        return;
      }
      const mapped: RowData[] = data.map((r: any) => ({
        id: r.id || uuidv4(),
        name: r.name || "",
        email: r.email || "",
        age: r.age ? Number(r.age) : null,
        role: r.role || "",
        ...r,
      }));
      dispatch(setRows(mapped));
      alert(`Imported ${mapped.length} rows`);
    } catch (err) {
      console.error(err);
      alert("Failed to parse CSV");
    }
  };

  return (
    <>
      <input
        type="file"
        accept=".csv"
        id="csv-input"
        style={{ display: "none" }}
        onChange={(e) => {
          const f = e.target.files?.[0];
          handleFile(f);
          (e.target as HTMLInputElement).value = "";
        }}
      />
      <label htmlFor="csv-input">
        <Button variant="outlined" component="span">Import CSV</Button>
      </label>
    </>
  );
}
