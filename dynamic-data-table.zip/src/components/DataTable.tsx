import React, { useMemo, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { RootState } from "../store/store";
import { FixedSizeList as List } from "react-window";
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, TableSortLabel, TablePagination, IconButton, TextField, Box, Button } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Close";
import { deleteRow, startEdit, setEditValue, saveAllEdits, cancelAllEdits } from "../slices/tableSlice";

export default function DataTable() {
  const dispatch = useDispatch();
  const rows = useSelector((s: RootState) => s.table.rows);
  const columns = useSelector((s: RootState) => s.table.columns);
  const columnOrder = useSelector((s: RootState) => s.table.columnOrder);
  const editedRows = useSelector((s: RootState) => s.table.editedRows);

  const [orderBy, setOrderBy] = useState<string>("name");
  const [order, setOrder] = useState<"asc" | "desc">("asc");
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState("");
  const rowsPerPage = 10;

  const visibleCols = useMemo(() => columnOrder.map(k => columns.find(c => c.key === k)).filter(Boolean).filter(c => c!.visible) as any[], [columnOrder, columns]);

  const handleSort = (colKey: string) => { if (orderBy === colKey) setOrder(prev => (prev === "asc" ? "desc" : "asc")); else { setOrderBy(colKey); setOrder("asc"); } };

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    let filteredRows = rows;
    if (q) filteredRows = rows.filter(r => Object.values(r).some(v => (v ?? "").toString().toLowerCase().includes(q)));
    filteredRows = filteredRows.slice().sort((a, b) => {
      const av = a[orderBy]; const bv = b[orderBy];
      if (av == null) return 1; if (bv == null) return -1;
      if (typeof av === "number" && typeof bv === "number") return order === "asc" ? av - bv : bv - av;
      return order === "asc" ? String(av).localeCompare(String(bv)) : String(bv).localeCompare(String(av));
    });
    return filteredRows;
  }, [rows, search, orderBy, order]);

  const pageRows = filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  const Row = ({ index, style }: { index: number; style: any }) => {
    const row = pageRows[index];
    const isEditing = !!editedRows[row.id];
    return (
      <TableRow key={row.id} style={style} hover>
        {visibleCols.map(col => {
          const value = isEditing ? (editedRows[row.id][col.key] ?? row[col.key]) : row[col.key];
          if (isEditing && col.editable) {
            return (
              <TableCell key={col.key}><TextField size="small" value={value ?? ""} onChange={e => dispatch(setEditValue({ id: row.id, key: col.key, value: col.key === "age" ? Number(e.target.value || null) : e.target.value }))} /></TableCell>
            );
          }
          return <TableCell key={col.key} onDoubleClick={() => dispatch(startEdit({ id: row.id, data: { ...row } }))}>{value as any}</TableCell>;
        })}
        <TableCell>
          <IconButton size="small" onClick={() => dispatch(startEdit({ id: row.id, data: { ...row } }))}><EditIcon /></IconButton>
          <IconButton size="small" onClick={() => { if (confirm("Delete row?")) dispatch(deleteRow(row.id)); }}><DeleteIcon /></IconButton>
        </TableCell>
      </TableRow>
    );
  };

  return (
    <Paper sx={{ p: 2 }}>
      <Box sx={{ display: "flex", gap: 2, alignItems: "center", mb: 2 }}>
        <TextField label="Global Search" size="small" value={search} onChange={e => { setSearch(e.target.value); setPage(0); }} />
        <Button variant="contained" onClick={() => dispatch(saveAllEdits())} startIcon={<SaveIcon />} disabled={Object.keys(editedRows).length === 0}>Save All</Button>
        <Button variant="outlined" onClick={() => dispatch(cancelAllEdits())} startIcon={<CancelIcon />} disabled={Object.keys(editedRows).length === 0}>Cancel All</Button>
      </Box>

      <TableContainer style={{ maxHeight: 480 }}>
        <Table stickyHeader size="small">
          <TableHead>
            <TableRow>
              {visibleCols.map(col => (
                <TableCell key={col.key} style={{ minWidth: col.width ?? 120 }}>
                  <TableSortLabel active={orderBy === col.key} direction={orderBy === col.key ? order : 'asc'} onClick={() => handleSort(col.key)}>
                    {col.label}
                  </TableSortLabel>
                </TableCell>
              ))}
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            <List height={Math.min(400, pageRows.length * 53)} itemCount={pageRows.length} itemSize={53} width="100%">
              {({ index, style }) => <Row index={index} style={style} />}
            </List>
          </TableBody>
        </Table>
      </TableContainer>

      <TablePagination component="div" count={filtered.length} page={page} onPageChange={(e, p) => setPage(p)} rowsPerPage={rowsPerPage} rowsPerPageOptions={[]} />
    </Paper>
  );
}
