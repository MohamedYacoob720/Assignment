import React from "react";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import Chip from "@mui/material/Chip";
import { useSelector } from "react-redux";
import { RootState } from "../store/store";

export default function SortableColumn({ id }: { id: string }) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    cursor: 'grab'
  };
  const col = useSelector((s: RootState) => s.table.columns.find(c => c.key === id));
  if (!col) return null;
  return <div ref={setNodeRef} style={style}><Chip label={col.label} {...attributes} {...listeners} /></div>;
}
