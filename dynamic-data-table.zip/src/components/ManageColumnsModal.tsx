import React from "react";
import { useForm } from "react-hook-form";
import { useSelector, useDispatch } from "react-redux";
import { RootState } from "../store/store";
import { toggleColumnVisibility, addCustomColumn } from "../slices/tableSlice";
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, FormControlLabel, Checkbox, TextField, Box } from "@mui/material";
import ColumnDnDContainer from "./ColumnDnDContainer";

export default function ManageColumnsModal({ open, onClose }: { open: boolean; onClose: () => void; }) {
  const dispatch = useDispatch();
  const columns = useSelector((s: RootState) => s.table.columns);
  const { register, handleSubmit, reset } = useForm<{ key: string; label: string }>();

  const onSubmit = (data: any) => {
    const key = data.key.trim();
    if (!key) return;
    dispatch(addCustomColumn({ key, label: data.label || key }));
    reset();
  };

  return (
    <Dialog open={open} onClose={onClose} fullWidth>
      <DialogTitle>Manage Columns</DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {columns.map(col => (
            <FormControlLabel key={col.key} control={<Checkbox checked={col.visible} onChange={e => dispatch(toggleColumnVisibility({ key: col.key, visible: e.target.checked }))} />} label={`${col.label} (${col.key})`} />
          ))}

          <Box component="form" onSubmit={handleSubmit(onSubmit)} sx={{ mt: 2, display: 'flex', gap: 1 }}>
            <TextField label="Key" size="small" {...register('key', { required: true })} />
            <TextField label="Label" size="small" {...register('label')} />
            <Button type="submit" variant="contained">Add</Button>
          </Box>

          <Box sx={{ mt: 2 }}>
            <div style={{ fontSize: 12, marginBottom: 8 }}>Reorder columns (preview):</div>
            <ColumnDnDContainer />
          </Box>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
}
