import React from "react";
import { DndContext, closestCenter } from "@dnd-kit/core";
import { arrayMove, SortableContext, horizontalListSortingStrategy } from "@dnd-kit/sortable";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../store/store";
import { setColumnOrder } from "../slices/tableSlice";
import SortableColumn from "./SortableColumn";

export default function ColumnDnDContainer() {
  const dispatch = useDispatch();
  const columnOrder = useSelector((s: RootState) => s.table.columnOrder);

  return (
    <DndContext collisionDetection={closestCenter} onDragEnd={(e) => {
      const { active, over } = e;
      if (!over) return;
      if (active.id !== over.id) {
        const oldIndex = columnOrder.indexOf(String(active.id));
        const newIndex = columnOrder.indexOf(String(over.id));
        const newOrder = arrayMove(columnOrder, oldIndex, newIndex);
        dispatch(setColumnOrder(newOrder));
      }
    }}>
      <SortableContext items={columnOrder} strategy={horizontalListSortingStrategy}>
        <div style={{ display: "flex", gap: 8 }}>
          {columnOrder.map(key => <SortableColumn key={key} id={key} />)}
        </div>
      </SortableContext>
    </DndContext>
  );
}
