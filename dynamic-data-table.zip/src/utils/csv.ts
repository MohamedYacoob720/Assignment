import Papa from "papaparse";
import { RowData, ColumnDef } from "../types";
import { saveAs } from "file-saver";

export function parseCsvFile(file: File): Promise<{ data: any[]; errors: any[]; headers: string[] }> {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const headers = results.meta.fields || [];
        resolve({ data: results.data, errors: results.errors, headers });
      },
      error: (err) => reject(err),
    });
  });
}

export function exportToCsv(rows: RowData[], columns: ColumnDef[]) {
  const visibleCols = columns.filter(c => c.visible);
  const keys = visibleCols.map(c => c.key);
  const header = visibleCols.map(c => c.label);
  const csvRows = [header.join(",")];

  rows.forEach(r => {
    const row = keys.map(k => `"\"${(r[k] ?? "").toString().replace(/"/g, '\"\"')}\""`).join(",");
    csvRows.push(row);
  });

  const blob = new Blob([csvRows.join("\n")], { type: "text/csv;charset=utf-8" });
  saveAs(blob, `table-export-${new Date().toISOString().slice(0,19)}.csv`);
}
