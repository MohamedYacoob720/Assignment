import { createTheme } from "@mui/material/styles";
import { ThemeOptions } from "@mui/material";

export function getTheme(mode: "light" | "dark") {
  const options: ThemeOptions = {
    palette: {
      mode,
    },
    components: {
      MuiPaper: { defaultProps: { elevation: 1 } },
    },
  };
  return createTheme(options);
}
