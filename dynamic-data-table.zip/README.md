# Dynamic Data Table Manager

## Setup

1. `npm install`
2. `npm run dev`
3. Open http://localhost:3000

## Features

- Sorting, global search, pagination
- Manage columns (add, show/hide, reorder)
- CSV import/export (PapaParse + FileSaver)
- Inline editing (Save All / Cancel All)
- Column drag-and-drop preview using `@dnd-kit`
- Virtualized rows using `react-window` for performance

## Deploy

Push to GitHub and connect to Vercel (Next.js auto-detects)
